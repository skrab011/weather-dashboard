# Handoff: Weather Dashboard Polish (4 changes)

## Overview
Four targeted design improvements to the existing weather-dashboard app (repo: `skrab011/weather-dashboard`, branch `main`), agreed after a design review:

1. **Hero temperature in the "Now" card** — promote the current temp from a table row to a large display value with condition + icon.
2. **Scannable 7-Day rows** — replace the 5-column stacked day/night micro-text with day-first rows featuring a temp-range bar; night details move behind a tap-to-expand.
3. **Alert event name in severity color** — the bold event title in alert banners takes the severity color instead of default foreground.
4. **Merged Mountain Weather Update footer** — the Tomer card currently renders two stacked footers ("Last updated" + "Posted"); merge into one line.

Everything else — color themes (V1 and V2), layout grid, chart, other cards — stays exactly as-is.

## About the Design Files
`Weather Dashboard Review.dc.html` in this bundle is a **design reference created in HTML** — a static mockup, not production code. It shows two full dashboards side by side: **1a** (faithful recreation of the current app) and **1b** (proposed). The task is to **implement the 1b deltas in the real codebase** (Vite + TypeScript, vanilla DOM string-template renderers) using its existing patterns — the shared card renderers in `src/shared/cards.ts` and the stylesheets `src/style.css` / `src/shared-page/style.css`. Do not port the mockup's inline styles wholesale; add CSS classes following the file's existing conventions.

## Fidelity
**High-fidelity.** The 1b mockup uses the app's exact design tokens. Recreate it pixel-perfectly. All values below are stated against the existing `:root` tokens in `src/style.css`.

## Important Codebase Facts
- Cards are rendered by pure functions in `src/shared/cards.ts` that write `innerHTML` into region divs. They are shared by two pages: V1 (`src/render.ts`, tokens in `src/style.css`) and V2 (`src/shared-page/render.ts`, token overrides in `src/shared-page/style.css`). **All four changes land in the shared renderers + shared CSS, so both pages pick them up.** Verify each change on both `/` and `/shared` (V2 has lighter surfaces — check contrast).
- V2 overrides only tokens and a few classes; use CSS custom properties (never raw hex) so V2 theming keeps working.
- Sample data in the mockup (July temps, Red Flag Warning, etc.) is illustrative only.

---

## Change 1 — "Now" card hero temperature

**File:** `src/shared/cards.ts` → `renderConditions()`. **CSS:** `src/style.css`.

### Current
Temp is an ordinary `.cond-row` (`Temp | 71°F 70°F`), followed by Wind, Sky, UV, Sunrise, Sunset rows.

### New
Replace the Temp row and the Sky row with a hero block at the top of the card (below the `Now` title), then keep the remaining rows (Wind, UV Index, Snow (24 hr) when present, Sunrise, Sunset) unchanged.

Hero block (`.cond-hero`):
- Container: `display:flex; align-items:center; gap:16px; padding: 2px 1rem 12px; border-bottom:1px solid var(--border);`
- **Big temp** (`.cond-hero__temp`): NWS temperature, `font-size:44px; font-weight:600; line-height:1; letter-spacing:-0.02em; color:var(--fg);` — text is `71°` (degree sign, no F).
- **Middle column** (`display:flex; flex-direction:column; gap:2px;`):
  - Condition (`shortForecast`, e.g. "Sunny"): `font-size:15px; font-weight:500;`
  - PurpleAir annotation (only when `showPaTemp` and PA temp available): `PurpleAir 70°F`, `font-size:0.8rem; color:#b09edc;` (reuses the existing `.temp-pa` color; note the label "PurpleAir" is new — it was previously an unlabeled number).
- **Condition icon**, right-aligned (`margin-left:auto; width:44px; height:44px; color:var(--fg-secondary);`): reuse the existing line-art icon system — `weatherIcon(period)` from `src/shared/weatherIcons.ts` already returns the right SVG for the current period. You may need a size wrapper class since `.hour-icon` is 34px.
- Skeleton/error/stale behavior unchanged.

## Change 2 — 7-Day forecast rows

**File:** `src/shared/cards.ts` → `renderForecast()` (+ `pairPeriods` unchanged). **CSS:** `src/style.css`.

### Current
Grid `80px 44px 1fr 80px 34px` (day | temp | outlook | wind | precip), each cell stacking day-value over night-value.

### New — collapsed row (default)
One line per day, grid columns: `72px 1fr 44px 34px 130px 34px 16px` with `gap:10px; padding:10px 1rem; border-bottom:1px solid var(--border); cursor:pointer;`

| Cell | Content | Style |
|---|---|---|
| Day | `Sun 7/6` (existing `fmtDay`) | `font-size:0.875rem; font-weight:500; white-space:nowrap;` |
| Outlook | day `shortForecast` only | `font-size:0.875rem;` ellipsis overflow |
| Precip | day precip % | `font-size:13px; color:var(--info); text-align:right;` |
| Lo | night temp `44°` | `font-size:13px; color:var(--fg-secondary); text-align:right;` |
| Range bar | see below | — |
| Hi | day temp `71°` | `font-size:13px; font-weight:600;` |
| Chevron | `▸` collapsed / `▾` expanded | `font-size:11px; color:var(--muted);` expanded: `color:var(--accent);` |

**Temp-range bar** (`.fc-range`): track `height:6px; background:var(--surface-raised); border-radius:3px; position:relative;`. Fill: absolutely positioned span, `background:linear-gradient(90deg, #7e6bb0, var(--accent)); border-radius:3px;`. Position/width computed against the **week's min/max across all lo/hi values**:
- `left = (lo − weekMin) / (weekMax − weekMin) × 100%`
- `width = (hi − lo) / (weekMax − weekMin) × 100%`
- Handle nulls (first "Tonight" row with no day period): fall back to showing just the available value; skip the bar if either temp is missing.

### New — expanded state (per-row toggle, click anywhere on the row)
- Row + detail wrapper gets a slightly raised background: `background:#171a23;` on V1 — define it as a token-relative value, e.g. `color-mix(in srgb, var(--surface) 85%, var(--surface-raised))`, so V2 inherits sensibly.
- Detail line below the row: `display:flex; gap:24px; padding:0 1rem 12px 98px;` containing three labeled stacks (label: `font-size:11px; color:var(--muted); text-transform:uppercase; letter-spacing:0.05em;`, value: `font-size:13px; color:var(--fg-secondary);`):
  - **Night** — night `shortForecast` + night precip: `Chance T-storms · 30%`
  - **Wind day** — existing wind-arrow span (rotate per `WIND_DIR_DEG`) + `SW 10–15 mph`
  - **Wind night** — same for night period
- State: a simple `Set<number>` of expanded row indices held in the render layer (or module-local in `cards.ts`), re-rendered on click, same pattern as the existing chart-var toggle callbacks. Collapse-by-default on location/tab switch is fine.
- Accessibility: row is a `<button>` or has `role="button"` + `aria-expanded`.

## Change 3 (review item 4) — alert event name in severity color

**File:** `src/style.css` only (markup already has `.alert-banner--danger|warn|info` on the parent).

```css
.alert-banner--danger .alert-event { color: var(--danger); }
.alert-banner--warn   .alert-event { color: var(--warn); }
.alert-banner--info   .alert-event { color: var(--info); }
```

## Change 4 (review item 5) — merge Tomer card footers

**File:** `src/shared/cards.ts` → `renderTomer()`.

Currently renders `cardFooter(ts, …)` **plus** a second `<footer class="card-footer tomer-published">Posted …</footer>`. Replace with a single footer line:

```
Posted Sat, Jul 4 · Last updated 6:45 AM
```

i.e. one `card-footer` whose content is `Posted ${published} · Last updated ${fmtTime(ts)}` (keep the error part of `cardFooter` behavior when stale). Delete the `.tomer-published` CSS rule.

---

## Design Tokens (existing — do not change)
From `src/style.css` `:root`: `--bg #0b0d11`, `--surface #13161d`, `--surface-raised #1c2030`, `--border #252a38`, `--fg #e6e8eb`, `--fg-secondary #9aa3b2`, `--muted #6b7280`, `--accent #b39ddb`, `--accent-dim #241c3a`, `--danger #ef4444`, `--warn #f59e0b`, `--info #b39ddb`, `--radius 12px`, `--radius-sm 8px`. V2 overrides live in `src/shared-page/style.css` and must keep working.

New values introduced by this design:
- Range-bar gradient start: `#7e6bb0` (darker lavender; pairs with `--accent`)
- Hero temp: `44px / 600 / -0.02em`
- Expanded-row background: `#171a23` on V1 (prefer a token-relative `color-mix`)

## Assets
None. The condition icon in the hero reuses the existing inline-SVG glyph set in `src/shared/weatherIcons.ts`.

## Files in this bundle
- `Weather Dashboard Review.dc.html` — side-by-side mockup; **1a** = current app (reference), **1b** = target design. Open in a browser; purple chips in 1b mark the changed cards.

## Verification checklist
- [ ] `/` (V1) and `/shared` (V2) both render all four changes; V2 contrast OK
- [ ] Now card: hero temp + condition + icon; Wind/UV/Sun rows intact; PA temp only where `showPaTemp`
- [ ] 7-Day: bars scale to week min/max; "Tonight"-only first row doesn't break; expand/collapse works per row
- [ ] Alert event titles colored per severity for danger/warn/info
- [ ] Tomer card shows exactly one footer
- [ ] Skeleton, error, and stale-data states unchanged for all touched cards
